"""
Linux memory forensics plugins.
"""
